--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.4 (Ubuntu 13.4-4.pgdg20.04+1)
-- Dumped by pg_dump version 14.0 (Ubuntu 14.0-1.pgdg20.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE muna_store;
--
-- Name: muna_store; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE muna_store WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_NG';


ALTER DATABASE muna_store OWNER TO postgres;

\connect muna_store

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: boot; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.boot (
    seller_id integer NOT NULL,
    firstname character varying(200) NOT NULL,
    lastname character varying(200) NOT NULL,
    manufacturer character varying(100)
);


ALTER TABLE public.boot OWNER TO postgres;

--
-- Name: boot_seller_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.boot_seller_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.boot_seller_id_seq OWNER TO postgres;

--
-- Name: boot_seller_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.boot_seller_id_seq OWNED BY public.boot.seller_id;


--
-- Name: smartphones; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.smartphones (
    phone_id integer NOT NULL,
    manufacturer character varying(150),
    model character varying(350) NOT NULL,
    release_year integer,
    memory integer NOT NULL,
    storage integer NOT NULL,
    amount numeric NOT NULL
);


ALTER TABLE public.smartphones OWNER TO postgres;

--
-- Name: consolidated_tables; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.consolidated_tables AS
 SELECT b1.seller_id,
    b1.firstname,
    b1.lastname,
    lower((("left"((b1.firstname)::text, 2) || (b1.lastname)::text) || 'gmail.com'::text)) AS email,
    s1.manufacturer,
    s1.model,
    s1.release_year,
    s1.storage,
    s1.memory,
    s1.amount
   FROM (public.boot b1
     RIGHT JOIN public.smartphones s1 ON (((b1.manufacturer)::text = (s1.manufacturer)::text)));


ALTER TABLE public.consolidated_tables OWNER TO postgres;

--
-- Name: count_of_model; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.count_of_model AS
 SELECT count(DISTINCT consolidated_tables.model) AS count
   FROM public.consolidated_tables;


ALTER TABLE public.count_of_model OWNER TO postgres;

--
-- Name: list_of_model; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.list_of_model AS
 SELECT DISTINCT consolidated_tables.model
   FROM public.consolidated_tables;


ALTER TABLE public.list_of_model OWNER TO postgres;

--
-- Name: modified_boot; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.modified_boot AS
 SELECT b1.seller_id,
    b1.firstname,
    b1.lastname,
    lower((("left"((b1.firstname)::text, 2) || (b1.lastname)::text) || 'gmail.com'::text)) AS email,
    s1.manufacturer,
    s1.model,
    s1.release_year,
    s1.storage,
    s1.memory,
    s1.amount AS price
   FROM (public.boot b1
     RIGHT JOIN public.smartphones s1 ON (((b1.manufacturer)::text = (s1.manufacturer)::text)));


ALTER TABLE public.modified_boot OWNER TO postgres;

--
-- Name: phone_counts; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.phone_counts AS
 SELECT sum(
        CASE smartphones.manufacturer
            WHEN 'Nokia'::text THEN 1
            ELSE 0
        END) AS count_of_nokia,
    sum(
        CASE smartphones.manufacturer
            WHEN 'Samsung'::text THEN 1
            ELSE 0
        END) AS count_of_samsung
   FROM public.smartphones;


ALTER TABLE public.phone_counts OWNER TO postgres;

--
-- Name: price_by_year; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.price_by_year AS
 SELECT modified_boot.release_year,
    sum(modified_boot.price) AS sum
   FROM public.modified_boot
  GROUP BY modified_boot.release_year
  ORDER BY modified_boot.release_year;


ALTER TABLE public.price_by_year OWNER TO postgres;

--
-- Name: rewards; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.rewards AS
 SELECT consolidated_tables.firstname,
    consolidated_tables.lastname,
    sum(consolidated_tables.amount) AS sum,
        CASE
            WHEN (sum(consolidated_tables.amount) >= (1000000)::numeric) THEN 'Gold'::text
            ELSE 'Bronze'::text
        END AS "case"
   FROM public.consolidated_tables
  GROUP BY consolidated_tables.firstname, consolidated_tables.lastname
  ORDER BY (sum(consolidated_tables.amount)) DESC;


ALTER TABLE public.rewards OWNER TO postgres;

--
-- Name: sale_by_year; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.sale_by_year AS
 SELECT consolidated_tables.release_year,
    sum(consolidated_tables.amount) AS total_sales
   FROM public.consolidated_tables
  GROUP BY consolidated_tables.release_year
  ORDER BY consolidated_tables.release_year;


ALTER TABLE public.sale_by_year OWNER TO postgres;

--
-- Name: smartphones_phone_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.smartphones_phone_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.smartphones_phone_id_seq OWNER TO postgres;

--
-- Name: smartphones_phone_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.smartphones_phone_id_seq OWNED BY public.smartphones.phone_id;


--
-- Name: total_sales_by_salesman; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.total_sales_by_salesman AS
 SELECT consolidated_tables.firstname,
    consolidated_tables.lastname,
    sum(consolidated_tables.amount) AS total_sale
   FROM public.consolidated_tables
  GROUP BY consolidated_tables.firstname, consolidated_tables.lastname;


ALTER TABLE public.total_sales_by_salesman OWNER TO postgres;

--
-- Name: boot seller_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.boot ALTER COLUMN seller_id SET DEFAULT nextval('public.boot_seller_id_seq'::regclass);


--
-- Name: smartphones phone_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.smartphones ALTER COLUMN phone_id SET DEFAULT nextval('public.smartphones_phone_id_seq'::regclass);


--
-- Data for Name: boot; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.boot (seller_id, firstname, lastname, manufacturer) FROM stdin;
\.
COPY public.boot (seller_id, firstname, lastname, manufacturer) FROM '$$PATH$$/3048.dat';

--
-- Data for Name: smartphones; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.smartphones (phone_id, manufacturer, model, release_year, memory, storage, amount) FROM stdin;
\.
COPY public.smartphones (phone_id, manufacturer, model, release_year, memory, storage, amount) FROM '$$PATH$$/3046.dat';

--
-- Name: boot_seller_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.boot_seller_id_seq', 24, true);


--
-- Name: smartphones_phone_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.smartphones_phone_id_seq', 27, true);


--
-- Name: boot boot_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.boot
    ADD CONSTRAINT boot_pkey PRIMARY KEY (seller_id);


--
-- Name: smartphones smartphones_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.smartphones
    ADD CONSTRAINT smartphones_pkey PRIMARY KEY (phone_id);


--
-- PostgreSQL database dump complete
--

